getwd()
setwd("C:/Users/studentas/Desktop")
if(!file.exists("data")){
        dir.create("data")
}

#atsisiunciam duomenis ir i pavadinima itraukiame siandienos data

URL <- "http://atvira.sodra.lt/csv/lt-eur/apdraustieji_3_1.csv"
Sys.time()
DownloadDate <- format(Sys.time(),format = "%Y_%m_%d")
filename <- paste("./data/apdraustieji_3_1_",
                  DownloadDate,
                  ".csv",
                  sep = "")
filename
download.file(
        url = URL,
        destfile = filename,
        method = "auto")

# persikopijuot

URL <- "http://atvira.sodra.lt/downloads/lt-eur/apdraustuju_pajamu_analize.zip"
DownloadDate <- format(Sys.time(),format = "%Y_%m_%d")
filename <- paste("./data/apdraustuju_pajamu_analize_",
                  DownloadDate,
                  ".zip",
                  sep = "")
filename
download.file(
        url = URL,
        destfile = filename,
        method = "auto")
unzip(filename,
      exdir = "data",
      files = "apdraustuju_pajamu_analize.csv")

#vel kopijuojam

URL <- "http://atvira.sodra.lt/downloads/lt-eur/apdraustuju_pajamu_analize.zip"
temp <- tempfile()
download.file(url = URL, temp, method = "auto")
GYV_PAJ <- read.csv(unzip(temp,"apdraustuju_pajamu_analize.csv"),
                    header = TRUE,
                    sep = ";",
                    stringsAsFactors = FALSE)
unlink(temp)
median(GYV_PAJ$Mėnesio.pajamos)
list(lower_bound = 0.5*median(GYV_PAJ$Mėnesio.pajamos),
     median=median(GYV_PAJ$Mėnesio.pajamos),
     upper_bound=2*median(GYV_PAJ$Mėnesio.pajamos))

maximum <- 4000
hist(GYV_PAJ$Mėnesio.pajamos[GYV_PAJ$Mėnesio.pajamos<=maximum],
     breaks=seq(0,maximum,100))

library(rsdmx)
url_meta <- "https://osp-rs.stat.gov.lt/rest_xml/dataflow/"
meta <- readSDMX(url_meta)
meta <- as.data.frame(meta)
write.csv(meta, "./data/meta.csv")
write.xlsx(meta, file="./data/meta.xlsx")

S3R106_M3020102_1 <- readSDMX(providerId = "LSD",
                              resource = "data",
                              flowRef = "S3R106_M3020102_1",
                              dsd = TRUE)
S3R106_M3020102_1 <- as.data.frame(S3R106_M3020102_1,
                                   labels = TRUE)

install.packages("eurostat")
library(eurostat)
nama_10_gdp <- get_eurostat("nama_10_gdp", stringsAsFactors = FALSE)
table(GYV_PAJ$Lytis, GYV_PAJ$Amžius)

df <- mtcars
df[c(1:3),]
df[c(1:3),c("mpg","cyl","hp")]
df[(df$mpg>=10 &
            df$mpg<=20& df$hp>=250 | df$qsec<=16),]
df$loginis <- ifelse(df$mpg>=mean(df$mpg),"daugiau","maziau")
head(df,3)

df2 <- read.csv("data/apdraustieji_3_1_2019_05_09.csv",
                header = TRUE,
                sep = ";",
                stringsAsFactors = FALSE)
df3 <- df2[(df2$Metai==2018 &
                   df2$Mėnesio.pajamos=="401-450 €"&
                   df2$Amžius=="Visos amžiaus grupės"&
                   df2$Lytis!="Visi apdraustieji"),]

table <- xtabs(data=df3,
               Apdraustųjų.skaičius ~ Lytis + Mėnuo,
               drop.unused.levels = TRUE)
table
barplot(table)

#pakeiciam menesius i skaicius, kad grazi lentele taptu
men <- c(Sausis=1, Vasaris=2,Kovas=3,Balandis=4,Gegužė=5, Birželis=6, Liepa=7, Rugpjūtis=8, Rugsėjis=9, Spalis=10, Lapkritis=11, Gruodis=12)
df3$men <- men[df3$Mėnuo]
table <- xtabs(data=df3,
               Apdraustųjų.skaičius ~ Lytis + men,
               drop.unused.levels = TRUE)
barplot(table)
#kerpam quantiliais
table(cut(GYV_PAJ$Mėnesio.pajamos, breaks=quantile(GYV_PAJ$Mėnesio.pajamos)))

library("Hmisc")
table(cut2(GYV_PAJ$Mėnesio.pajamos, g=4))
GYV_PAJ$fact <- cut2(GYV_PAJ$Mėnesio.pajamos, g=4)
GYV_PAJ$fact_num <- as.numeric(cut2(GYV_PAJ$Mėnesio.pajamos,g=4))

library("reshape2")
#Masinos pavadinima sukuriam is eilutes pavadinimo i stulpeli
mtcars$car_name <- rownames(mtcars)
View(mtcars)
mtcars_melt <- melt(mtcars, id=c("car_name", "gear", "cyl"), measure.vars = c("mpg", "hp"))
head(mtcars_melt,3)
tail(mtcars_melt,3)

dcast(mtcars_melt, cyl~variable)
acast(mtcars_melt, cyl~variable)

dcast(mtcars_melt, cyl~variable, mean)
dcast(mtcars_melt, gear~variable, mean)

set.seed(101)
a <- data.frame(id=sample(1:10), name=sample(letters[1:10],10),val1=sample(3,10,replace = T))
b <- data.frame(id=sample(1:10), name=sample(letters[1:10],10),val2=sample(3,10,replace = T))
a
b

merge(a,b)
merge(a,b, all = TRUE)
merge(a,b, by.x = "id", by.y = "id")

#dplyr cheatsheet https://www.rstudio.com/wp-content/uploads/2015/02/data-wrangling-cheatsheet.pdf

library("dplyr")
head(nama_10_gdp)
head(select(nama_10_gdp, 1:3))
head(select(nama_10_gdp, unit, geo, values))

filter(nama_10_gdp, geo=="LT")
df <- filter(nama_10_gdp, geo=="LT"&
                     na_item=="B1G"&
                     unit=="CLV10_MEUR"&
                     time>="2000-01-01")

#arrange grafikui apsukti, pvz BVP
